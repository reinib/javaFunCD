public class PythagoreanTest {
  public static void main(String[] args) {
    Pythagorean test = new Pythagorean();
    int a = 2;
    int b = 3;
    System.out.println(test.calculateHypotenuse(a, b));
  }
}
