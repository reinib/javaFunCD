public class BasicsTest {
  public static void main(String[] args) {
    Basics test = new Basics();
    int[]arr = {4, 8, -8, 5, 30, 3, -5, 1};
    // test.counter();
    // test.oddCounter();
    // test.printSum();
    // test.iterateArray();
    // test.findMax(arr);
    // test.findAverage(arr);
    // test.oddArray();
    // test.greaterThanY(arr, 3);
    // test.squareVals(arr);
    // test.eliminateNegs(arr);
    // test.maxMinAvg(arr);
    test.shiftValArray(arr);
  }
}
