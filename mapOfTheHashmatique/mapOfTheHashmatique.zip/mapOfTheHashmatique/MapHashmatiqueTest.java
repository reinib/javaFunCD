public class MapHashmatiqueTest {
  public static void main(String[] args) {
    MapHashmatique test = new MapHashmatique();
    test.mapHashmatique();
  }
}
