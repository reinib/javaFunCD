public class FizzBuzzTest {
  public static void main(String[] args) {
    FizzBuzz test = new FizzBuzz();
    int number = 9;
    System.out.println(test.fizzbuzz(number));
  }
}
