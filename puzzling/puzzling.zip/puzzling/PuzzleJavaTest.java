import java.util.ArrayList;
public class PuzzleJavaTest {
  public static void main(String[] args) {
    PuzzleJava test = new PuzzleJava();
    int[]arr = {3,5,1,2,7,9,8,13,25,32};
    ArrayList<String> abcArr = new ArrayList<String>();
    abcArr.add("a");
    abcArr.add("b");
    abcArr.add("c");
    abcArr.add("d");
    abcArr.add("e");
    abcArr.add("f");
    abcArr.add("g");
    abcArr.add("h");
    abcArr.add("i");
    abcArr.add("j");
    abcArr.add("k");
    abcArr.add("l");
    abcArr.add("m");
    abcArr.add("n");
    abcArr.add("o");
    abcArr.add("p");
    abcArr.add("q");
    abcArr.add("r");
    abcArr.add("s");
    abcArr.add("t");
    abcArr.add("u");
    abcArr.add("v");
    abcArr.add("w");
    abcArr.add("x");
    abcArr.add("y");
    abcArr.add("z");
    // test.sum(arr);
    // test.shuffleNames();
    // test.shuffleABC(abcArr);
    // ArrayList<Integer> randArr10 = test.randArray();
    // test.minMaxRandArraySort(randArr10);
    // test.randABCString();
    test.stringArray();
  }
}
