public class FirstJavaProgram {
    public static void main(String[] args) {
      System.out.println("My name is Brent\nI am 29 years old\nI'm from Seattle, WA :) ");
    }
}
